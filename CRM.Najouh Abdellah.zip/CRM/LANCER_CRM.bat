@echo off
setlocal
chcp 65001 >nul

set "PORT=5500"
set "ROOT=%~dp0"

echo ============================================
echo   Mini CRM - Lanceur local
echo ============================================
echo.
echo Dossier projet : %ROOT%
echo Port          : %PORT%
echo.
echo Le navigateur va s'ouvrir automatiquement.
echo Pour arreter le serveur : Ctrl + C dans cette fenetre.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$port=%PORT%; $root='%ROOT%';" ^
  "$listener = [System.Net.HttpListener]::new();" ^
  "$listener.Prefixes.Add(('http://localhost:{0}/' -f $port));" ^
  "try { $listener.Start() } catch { Write-Host 'Port deja utilise. Fermez l''autre serveur ou changez PORT dans LANCER_CRM.bat.' -ForegroundColor Red; Read-Host 'Appuyez sur Entree pour quitter'; exit 1 };" ^
  "Start-Process ('http://localhost:{0}/index.html#dashboard' -f $port);" ^
  "Write-Host ('Serveur actif sur http://localhost:{0}/' -f $port) -ForegroundColor Green;" ^
  "while ($listener.IsListening) {" ^
  "  try { $context = $listener.GetContext() } catch { break };" ^
  "  $reqPath = [Uri]::UnescapeDataString($context.Request.Url.AbsolutePath.TrimStart('/'));" ^
  "  if ([string]::IsNullOrWhiteSpace($reqPath)) { $reqPath = 'index.html' };" ^
  "  $localPath = Join-Path $root $reqPath;" ^
  "  if ((Test-Path $localPath) -and -not (Get-Item $localPath).PSIsContainer) {" ^
  "    $ext = [IO.Path]::GetExtension($localPath).ToLowerInvariant();" ^
  "    $mimeMap = @{'.html'='text/html; charset=utf-8'; '.css'='text/css; charset=utf-8'; '.js'='application/javascript; charset=utf-8'; '.json'='application/json; charset=utf-8'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.svg'='image/svg+xml'; '.ico'='image/x-icon'; '.txt'='text/plain; charset=utf-8'};" ^
  "    $mime = if ($mimeMap.ContainsKey($ext)) { $mimeMap[$ext] } else { 'application/octet-stream' };" ^
  "    $bytes = [IO.File]::ReadAllBytes($localPath);" ^
  "    $context.Response.StatusCode = 200;" ^
  "    $context.Response.ContentType = $mime;" ^
  "    $context.Response.ContentLength64 = $bytes.Length;" ^
  "    $context.Response.OutputStream.Write($bytes, 0, $bytes.Length);" ^
  "  } else {" ^
  "    $context.Response.StatusCode = 404;" ^
  "    $msg = [Text.Encoding]::UTF8.GetBytes('404 - Fichier introuvable');" ^
  "    $context.Response.ContentType = 'text/plain; charset=utf-8';" ^
  "    $context.Response.ContentLength64 = $msg.Length;" ^
  "    $context.Response.OutputStream.Write($msg, 0, $msg.Length);" ^
  "  };" ^
  "  $context.Response.OutputStream.Close();" ^
  "};" ^
  "$listener.Stop(); $listener.Close();"

endlocal
