import { initRouter } from "./router.js";
import { modelTemplates } from "./models.js";
import { loadDataStore } from "./storage.js";
import { getCurrentUser, loginWithCredentials, logoutUser } from "./auth.js";

async function bootstrap() {
  try {
    const store = await loadDataStore();
    console.info("Modeles de reference:", modelTemplates);
    initApp(store);
  } catch (error) {
    const title = document.getElementById("view-title");
    const content = document.getElementById("view-content");
    title.textContent = "Erreur de demarrage";
    content.innerHTML = `<div class="alert alert-danger mb-0">${error.message}</div>`;
  }
}

function initApp(store) {
  const logoutButton = document.getElementById("logout-btn");
  logoutButton.addEventListener("click", () => {
    logoutUser();
    renderLoginView(store);
  });

  const user = getCurrentUser();
  if (!user) {
    renderLoginView(store);
    return;
  }

  enterApplication(store);
}

function enterApplication(store) {
  const user = getCurrentUser();
  const navbar = document.getElementById("mainNavbar");
  const badge = document.getElementById("current-user-badge");
  const logoutButton = document.getElementById("logout-btn");

  navbar.classList.remove("d-none");
  navbar.classList.add("show");
  badge.classList.remove("d-none");
  logoutButton.classList.remove("d-none");
  badge.textContent = `${user.fullName} (${user.role})`;

  initRouter(store);
}

function renderLoginView(store) {
  const navbar = document.getElementById("mainNavbar");
  const badge = document.getElementById("current-user-badge");
  const logoutButton = document.getElementById("logout-btn");
  const title = document.getElementById("view-title");
  const content = document.getElementById("view-content");

  navbar.classList.remove("show");
  navbar.classList.add("d-none");
  badge.classList.add("d-none");
  logoutButton.classList.add("d-none");

  title.textContent = "Connexion";
  content.innerHTML = `
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-4">
        <div class="card">
          <div class="card-body">
            <h2 class="h5 mb-3">Login CRM</h2>
            <form id="login-form" novalidate>
              <div class="mb-3">
                <label class="form-label" for="login-username">Username</label>
                <input id="login-username" class="form-control" type="text" required />
              </div>
              <div class="mb-3">
                <label class="form-label" for="login-password">Password</label>
                <input id="login-password" class="form-control" type="password" required />
              </div>
              <button type="submit" class="btn btn-primary w-100">Se connecter</button>
              <p id="login-error" class="text-danger small mt-2 mb-0 d-none"></p>
            </form>
            <p class="small text-muted mt-3 mb-0">Comptes test: admin/admin123 ou commercial/commercial123</p>
          </div>
        </div>
      </div>
    </div>
  `;

  const form = document.getElementById("login-form");
  const usernameInput = document.getElementById("login-username");
  const passwordInput = document.getElementById("login-password");
  const errorNode = document.getElementById("login-error");

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const username = usernameInput.value.trim();
    const password = passwordInput.value;
    const user = loginWithCredentials(store.users, username, password);
    if (!user) {
      errorNode.textContent = "Identifiants invalides.";
      errorNode.classList.remove("d-none");
      return;
    }
    window.location.hash = "#dashboard";
    enterApplication(store);
  });
}

bootstrap();
