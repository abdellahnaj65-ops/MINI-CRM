const SESSION_KEY = "mini-crm:session-user";

export function getCurrentUser() {
  const raw = sessionStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function loginWithCredentials(users, username, password) {
  const user = users.find((item) => item.username === username && item.password === password && item.isActive !== false);
  if (!user) return null;

  const sessionUser = {
    id: user.id,
    username: user.username,
    fullName: user.fullName || user.username,
    role: user.role || "commercial",
  };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
  return sessionUser;
}

export function logoutUser() {
  sessionStorage.removeItem(SESSION_KEY);
}
