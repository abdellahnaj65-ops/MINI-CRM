import { saveCollection } from "./storage.js";
import { getCurrentUser } from "./auth.js";

const views = {
  dashboard: { title: "Dashboard", render: renderDashboard },
  users: { title: "Users", render: renderUsers },
  prospects: { title: "Prospects", render: renderProspects },
  produits: { title: "Produits", render: renderProduits },
  opportunites: { title: "Opportunites", render: renderOpportunites },
  devis: { title: "Devis", render: renderDevis },
  factures: { title: "Factures", render: renderFactures },
  paiements: { title: "Paiements", render: renderPaiements },
};

function getRouteFromHash() {
  const raw = window.location.hash.replace("#", "").trim();
  return raw || "dashboard";
}

function activateCurrentNav(route) {
  document.querySelectorAll(".route-link").forEach((link) => {
    const isCurrent = link.getAttribute("href") === `#${route}`;
    link.classList.toggle("active", isCurrent);
    link.setAttribute("aria-current", isCurrent ? "page" : "false");
  });
}

function renderEmptyBlock(message) {
  return `<div class="placeholder-block">${message}</div>`;
}

function renderDashboard(store) {
  const activeOpportunities = store.opportunites.filter((item) => item.stage !== "gagne" && item.stage !== "perdu").length;
  const pipeline = store.opportunites
    .filter((item) => item.stage !== "perdu")
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const invoiced = store.factures.reduce((sum, item) => sum + Number(item.total || 0), 0);
  const collected = store.paiements.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const remaining = store.factures.reduce((sum, item) => sum + Number(item.remainingAmount || 0), 0);

  return `
    <div class="row g-3 mb-3">
      <div class="col-md-12">
        <label class="form-label mb-1">Recherche globale</label>
        <div class="d-flex gap-2">
          <input id="js-global-search" class="form-control" type="search" placeholder="Rechercher dans prospects, opportunites, devis, factures..." />
          <select id="js-global-filter" class="form-select" style="max-width: 220px;">
            <option value="all">Toutes les entites</option>
            <option value="prospects">Prospects</option>
            <option value="opportunites">Opportunites</option>
            <option value="devis">Devis</option>
            <option value="factures">Factures</option>
          </select>
        </div>
      </div>
      <div class="col-12">
        <div class="d-flex gap-2 flex-wrap">
          <button class="btn btn-outline-secondary btn-sm js-export-csv" data-entity="prospects">Export CSV prospects</button>
          <button class="btn btn-outline-secondary btn-sm js-export-csv" data-entity="opportunites">Export CSV opportunites</button>
          <button class="btn btn-outline-secondary btn-sm js-export-csv" data-entity="devis">Export CSV devis</button>
          <button class="btn btn-outline-secondary btn-sm js-export-csv" data-entity="factures">Export CSV factures</button>
        </div>
      </div>
      <div class="col-12">
        <div id="js-global-results" class="placeholder-block">Tapez un mot-cle pour afficher les resultats.</div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Prospects</p><h2 class="h4 mb-0">${store.prospects.length}</h2></div></div></div>
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Produits</p><h2 class="h4 mb-0">${store.produits.length}</h2></div></div></div>
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Opportunites actives</p><h2 class="h4 mb-0">${activeOpportunities}</h2></div></div></div>
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Montant pipeline</p><h2 class="h4 mb-0">${formatAmount(pipeline)} MAD</h2></div></div></div>
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Total facture</p><h2 class="h4 mb-0">${formatAmount(invoiced)} MAD</h2></div></div></div>
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Montant encaisse</p><h2 class="h4 mb-0">${formatAmount(collected)} MAD</h2></div></div></div>
      <div class="col-md-4"><div class="card kpi-card"><div class="card-body"><p class="text-muted mb-1">Reste a encaisser</p><h2 class="h4 mb-0">${formatAmount(remaining)} MAD</h2></div></div></div>
    </div>
  `;
}

function renderUsers(store) {
  if (!isAdmin()) {
    return `<div class="alert alert-warning mb-0">Acces refuse: seul l'admin peut gerer les utilisateurs.</div>`;
  }

  const rows = store.users
    .map(
      (user) => `
      <tr>
        <td>${user.id}</td>
        <td>${user.username}</td>
        <td>${user.fullName || "-"}</td>
        <td><span class="badge text-bg-${user.role === "admin" ? "primary" : "secondary"}">${user.role}</span></td>
        <td><span class="badge text-bg-${user.isActive ? "success" : "danger"}">${user.isActive ? "actif" : "inactif"}</span></td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-1 js-edit-user" data-id="${user.id}">Modifier</button>
          <button class="btn btn-sm btn-outline-danger js-delete-user" data-id="${user.id}">Supprimer</button>
        </td>
      </tr>
    `
    )
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="mb-0 text-muted">Total users: ${store.users.length}</p>
      <button class="btn btn-primary" id="js-new-user">Nouveau user</button>
    </div>

    <div id="js-user-form-wrapper" class="card mb-3 d-none">
      <div class="card-body">
        <h3 class="h6 mb-3" id="js-user-form-title">Nouveau user</h3>
        <form id="js-user-form" novalidate>
          <input type="hidden" id="user-id" />
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label" for="user-username">Username *</label>
              <input id="user-username" class="form-control" type="text" required />
            </div>
            <div class="col-md-4">
              <label class="form-label" for="user-fullname">Nom complet</label>
              <input id="user-fullname" class="form-control" type="text" />
            </div>
            <div class="col-md-2">
              <label class="form-label" for="user-role">Role *</label>
              <select id="user-role" class="form-select">
                <option value="admin">admin</option>
                <option value="commercial">commercial</option>
              </select>
            </div>
            <div class="col-md-2">
              <label class="form-label" for="user-active">Actif</label>
              <select id="user-active" class="form-select">
                <option value="true">Oui</option>
                <option value="false">Non</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label" for="user-password">Password *</label>
              <input id="user-password" class="form-control" type="text" required />
            </div>
          </div>
          <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <button type="button" class="btn btn-outline-secondary" id="js-cancel-user-form">Annuler</button>
          </div>
          <p class="text-danger mt-2 mb-0 small d-none" id="js-user-form-error"></p>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr><th>ID</th><th>Username</th><th>Nom</th><th>Role</th><th>Etat</th><th class="text-end">Actions</th></tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="6" class="text-center text-muted py-4">Aucun user</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

function renderProduits(store) {
  const rows = store.produits
    .map(
      (product) => `
      <tr>
        <td>${product.id}</td>
        <td>${product.name}</td>
        <td>${product.description || "-"}</td>
        <td>${formatAmount(product.unitPrice)} MAD</td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-1 js-edit-product" data-id="${product.id}">Modifier</button>
          ${isAdmin() ? `<button class="btn btn-sm btn-outline-danger js-delete-product" data-id="${product.id}">Supprimer</button>` : ""}
        </td>
      </tr>
    `
    )
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="mb-0 text-muted">Total produits: ${store.produits.length}</p>
      ${isAdmin() ? '<button class="btn btn-primary" id="js-new-product">Nouveau produit</button>' : '<span class="badge text-bg-warning">Lecture seule (commercial)</span>'}
    </div>

    <div id="js-product-form-wrapper" class="card mb-3 d-none">
      <div class="card-body">
        <h3 class="h6 mb-3" id="js-product-form-title">Nouveau produit</h3>
        <form id="js-product-form" novalidate>
          <input type="hidden" id="product-id" />
          <div class="row g-3">
            <div class="col-md-5">
              <label class="form-label" for="product-name">Nom *</label>
              <input id="product-name" class="form-control" type="text" required />
            </div>
            <div class="col-md-5">
              <label class="form-label" for="product-description">Description</label>
              <input id="product-description" class="form-control" type="text" />
            </div>
            <div class="col-md-2">
              <label class="form-label" for="product-price">Prix *</label>
              <input id="product-price" class="form-control" type="number" min="0" required />
            </div>
          </div>
          <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <button type="button" class="btn btn-outline-secondary" id="js-cancel-product-form">Annuler</button>
          </div>
          <p class="text-danger mt-2 mb-0 small d-none" id="js-product-form-error"></p>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr><th>ID</th><th>Nom</th><th>Description</th><th>Prix unitaire</th><th class="text-end">Actions</th></tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="5" class="text-center text-muted py-4">Aucun produit</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

function renderProspects(store) {
  const rows = store.prospects
    .map(
      (prospect) => `
      <tr>
        <td>${prospect.id}</td>
        <td>${prospect.fullName}</td>
        <td>${prospect.company || "-"}</td>
        <td>${prospect.email}</td>
        <td>${prospect.phone || "-"}</td>
        <td><span class="badge text-bg-${prospect.status === "client" ? "success" : "secondary"}">${prospect.status}</span></td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-1 js-edit-prospect" data-id="${prospect.id}">Modifier</button>
          ${isAdmin() ? `<button class="btn btn-sm btn-outline-danger js-delete-prospect" data-id="${prospect.id}">Supprimer</button>` : ""}
        </td>
      </tr>
    `
    )
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="mb-0 text-muted">Total: ${store.prospects.length} contact(s)</p>
      <button class="btn btn-primary" id="js-new-prospect">Nouveau contact</button>
    </div>

    <div class="row g-3 mb-3">
      <div class="col-md-6">
        <input type="search" id="js-search-prospect" class="form-control" placeholder="Rechercher (nom, entreprise, email)" />
      </div>
    </div>

    <div id="js-prospect-form-wrapper" class="card mb-3 d-none">
      <div class="card-body">
        <h3 class="h6 mb-3" id="js-form-title">Nouveau prospect</h3>
        <form id="js-prospect-form" novalidate>
          <input type="hidden" id="prospect-id" />
          <div class="row g-3">
            <div class="col-md-6">
              <label for="fullName" class="form-label">Nom complet *</label>
              <input type="text" class="form-control" id="fullName" required />
            </div>
            <div class="col-md-6">
              <label for="company" class="form-label">Entreprise</label>
              <input type="text" class="form-control" id="company" />
            </div>
            <div class="col-md-6">
              <label for="email" class="form-label">Email *</label>
              <input type="email" class="form-control" id="email" required />
            </div>
            <div class="col-md-6">
              <label for="phone" class="form-label">Telephone *</label>
              <input type="text" class="form-control" id="phone" required />
            </div>
            <div class="col-md-6">
              <label for="status" class="form-label">Statut *</label>
              <select id="status" class="form-select" required>
                <option value="prospect">prospect</option>
                <option value="client">client</option>
              </select>
            </div>
          </div>
          <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <button type="button" class="btn btn-outline-secondary" id="js-cancel-form">Annuler</button>
          </div>
          <p class="text-danger mt-2 mb-0 small d-none" id="js-form-error"></p>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>ID</th><th>Nom</th><th>Entreprise</th><th>Email</th><th>Telephone</th><th>Statut</th><th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody id="js-prospect-table-body">
          ${rows || '<tr><td colspan="7" class="text-center text-muted py-4">Aucun prospect</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

function renderOpportunites(store) {
  const stages = [
    { key: "nouveau", label: "Nouveau" },
    { key: "en_cours", label: "En cours" },
    { key: "negociation", label: "Negociation" },
    { key: "gagne", label: "Gagne" },
    { key: "perdu", label: "Perdu" },
  ];

  const stageColumns = stages
    .map((stage) => {
      const items = store.opportunites.filter((opportunity) => opportunity.stage === stage.key);
      const cards = items
        .map(
          (item) => `
          <div class="card mb-2 shadow-sm">
            <div class="card-body p-2">
              <p class="fw-semibold mb-1">${item.title}</p>
              <p class="mb-1 small text-muted">${resolveProspectName(store, item.prospectId)}</p>
              <p class="mb-2 small">Montant: ${formatAmount(item.amount)} MAD</p>
              <div class="d-flex gap-1 flex-wrap">
                <button class="btn btn-sm btn-outline-primary js-edit-opportunity" data-id="${item.id}">Modifier</button>
                <button class="btn btn-sm btn-outline-secondary js-move-opportunity" data-id="${item.id}" data-direction="prev">&lt;</button>
                <button class="btn btn-sm btn-outline-secondary js-move-opportunity" data-id="${item.id}" data-direction="next">&gt;</button>
              </div>
            </div>
          </div>
        `
        )
        .join("");

      return `
        <div class="col-md-6 col-xl">
          <div class="card h-100">
            <div class="card-header fw-semibold">${stage.label} (${items.length})</div>
            <div class="card-body kanban-column-body" data-stage="${stage.key}">
              ${cards || '<p class="text-muted small mb-0">Aucune opportunite</p>'}
            </div>
          </div>
        </div>
      `;
    })
    .join("");

  const pipelineAmount = store.opportunites
    .filter((item) => item.stage !== "perdu")
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const prospectOptions = store.prospects
    .map((prospect) => `<option value="${prospect.id}">${prospect.fullName}</option>`)
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <div>
        <p class="mb-0 text-muted">Total opportunites: ${store.opportunites.length}</p>
        <p class="mb-0 fw-semibold">Pipeline (hors perdu): ${formatAmount(pipelineAmount)} MAD</p>
      </div>
      <button class="btn btn-primary" id="js-new-opportunity">Nouvelle opportunite</button>
    </div>

    <div id="js-opportunity-form-wrapper" class="card mb-3 d-none">
      <div class="card-body">
        <h3 class="h6 mb-3" id="js-opportunity-form-title">Nouvelle opportunite</h3>
        <form id="js-opportunity-form" novalidate>
          <input type="hidden" id="opportunity-id" />
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label" for="opp-title">Titre *</label>
              <input class="form-control" id="opp-title" type="text" required />
            </div>
            <div class="col-md-6">
              <label class="form-label" for="opp-prospect">Prospect/Client *</label>
              <select class="form-select" id="opp-prospect" required>
                <option value="">Selectionner</option>
                ${prospectOptions}
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label" for="opp-amount">Montant estime (MAD) *</label>
              <input class="form-control" id="opp-amount" type="number" min="0" required />
            </div>
            <div class="col-md-4">
              <label class="form-label" for="opp-probability">Probabilite (%) *</label>
              <input class="form-control" id="opp-probability" type="number" min="0" max="100" required />
            </div>
            <div class="col-md-4">
              <label class="form-label" for="opp-stage">Etape *</label>
              <select class="form-select" id="opp-stage" required>
                <option value="nouveau">Nouveau</option>
                <option value="en_cours">En cours</option>
                <option value="negociation">Negociation</option>
                <option value="gagne">Gagne</option>
                <option value="perdu">Perdu</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label" for="opp-close-date">Date previsionnelle de cloture *</label>
              <input class="form-control" id="opp-close-date" type="date" required />
            </div>
          </div>
          <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <button type="button" class="btn btn-outline-secondary" id="js-cancel-opportunity-form">Annuler</button>
          </div>
          <p class="text-danger mt-2 mb-0 small d-none" id="js-opportunity-form-error"></p>
        </form>
      </div>
    </div>

    <div class="row g-3">
      ${stageColumns}
    </div>
  `;
}

function renderDevis(store) {
  const filteredRows = store.devis
    .map((quote) => {
      const contact = resolveProspectName(store, quote.prospectId);
      return `
        <tr>
          <td>${quote.id}</td>
          <td>${contact}</td>
          <td><span class="badge text-bg-${quoteStatusColor(quote.status)}">${quote.status}</span></td>
          <td>${formatAmount(quote.total)} MAD</td>
          <td>${quote.createdAt || "-"}</td>
          <td class="text-end">
            <button class="btn btn-sm btn-outline-success me-1 js-convert-quote" data-id="${quote.id}" ${quote.status !== "accepte" ? "disabled" : ""}>Facturer</button>
            <button class="btn btn-sm btn-outline-primary me-1 js-edit-quote" data-id="${quote.id}">Modifier</button>
            ${isAdmin() ? `<button class="btn btn-sm btn-outline-danger js-delete-quote" data-id="${quote.id}">Supprimer</button>` : ""}
          </td>
        </tr>
      `;
    })
    .join("");

  const prospectOptions = store.prospects
    .map((prospect) => `<option value="${prospect.id}">${prospect.fullName}</option>`)
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="mb-0 text-muted">Total devis: ${store.devis.length}</p>
      <div class="d-flex gap-2">
        <a href="#produits" class="btn btn-outline-primary">Gerer produits</a>
        <button class="btn btn-primary" id="js-new-quote">Nouveau devis</button>
      </div>
    </div>

    <div class="row g-2 mb-3">
      <div class="col-md-5">
        <input type="search" id="js-search-quote" class="form-control" placeholder="Rechercher par ID ou contact" />
      </div>
      <div class="col-md-3">
        <select id="js-filter-quote-status" class="form-select">
          <option value="">Tous les statuts</option>
          <option value="brouillon">brouillon</option>
          <option value="envoye">envoye</option>
          <option value="accepte">accepte</option>
          <option value="refuse">refuse</option>
        </select>
      </div>
    </div>

    <div id="js-quote-form-wrapper" class="card mb-3 d-none">
      <div class="card-body">
        <h3 class="h6 mb-3" id="js-quote-form-title">Nouveau devis</h3>
        <form id="js-quote-form" novalidate>
          <input type="hidden" id="quote-id" />
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label" for="quote-prospect">Prospect/Client *</label>
              <select id="quote-prospect" class="form-select" required>
                <option value="">Selectionner</option>
                ${prospectOptions}
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label" for="quote-status">Statut *</label>
              <select id="quote-status" class="form-select" required>
                <option value="brouillon">brouillon</option>
                <option value="envoye">envoye</option>
                <option value="accepte">accepte</option>
                <option value="refuse">refuse</option>
              </select>
            </div>
          </div>

          <hr />
          <div class="d-flex justify-content-between align-items-center mb-2">
            <p class="mb-0 fw-semibold">Lignes du devis</p>
            <button type="button" class="btn btn-sm btn-outline-secondary" id="js-add-quote-line">Ajouter ligne</button>
          </div>
          <div id="js-quote-lines"></div>

          <div class="mt-3">
            <p class="mb-1">Sous-total: <span id="js-quote-subtotal">0</span> MAD</p>
            <p class="mb-0 fw-semibold">Total: <span id="js-quote-total">0</span> MAD</p>
          </div>

          <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-success">Enregistrer</button>
            <button type="button" class="btn btn-outline-secondary" id="js-cancel-quote-form">Annuler</button>
          </div>
          <p class="text-danger mt-2 mb-0 small d-none" id="js-quote-form-error"></p>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>ID</th><th>Contact</th><th>Statut</th><th>Total</th><th>Date creation</th><th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody id="js-quote-table-body">
          ${filteredRows || '<tr><td colspan="6" class="text-center text-muted py-4">Aucun devis</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

function renderFactures(store) {
  const rows = store.factures
    .map((invoice) => {
      const quote = store.devis.find((item) => item.id === invoice.devisId);
      const contact = quote ? resolveProspectName(store, quote.prospectId) : "Contact inconnu";
      const productNames = (invoice.lines || [])
        .map((line) => line.productName || line.description || "Produit")
        .slice(0, 2)
        .join(", ");
      return `
        <tr>
          <td>${invoice.id}</td>
          <td>${invoice.devisId}</td>
          <td>${contact}</td>
          <td class="small">${productNames || "-"}</td>
          <td><span class="badge text-bg-${invoiceStatusColor(invoice.status)}">${invoice.status}</span></td>
          <td>${formatAmount(invoice.total)} MAD</td>
          <td>${formatAmount(invoice.paidAmount)} MAD</td>
          <td>${formatAmount(invoice.remainingAmount)} MAD</td>
          <td>${invoice.createdAt || "-"}</td>
        </tr>
      `;
    })
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="mb-0 text-muted">Total factures: ${store.factures.length}</p>
      <a href="#devis" class="btn btn-outline-primary">Aller aux devis</a>
    </div>

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>Facture</th><th>Devis</th><th>Contact</th><th>Produits</th><th>Statut</th><th>Total</th><th>Encaisse</th><th>Reste</th><th>Date</th>
          </tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="9" class="text-center text-muted py-4">Aucune facture</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

function renderPaiements(store) {
  const invoiceOptions = store.factures
    .filter((invoice) => Number(invoice.remainingAmount) > 0)
    .map(
      (invoice) =>
        `<option value="${invoice.id}">${invoice.id} - Reste ${formatAmount(invoice.remainingAmount)} MAD</option>`
    )
    .join("");

  const rows = store.paiements
    .map(
      (payment) => `
        <tr>
          <td>${payment.id}</td>
          <td>${payment.invoiceId}</td>
          <td>${formatAmount(payment.amount)} MAD</td>
          <td>${payment.method}</td>
          <td>${payment.paidAt}</td>
        </tr>
      `
    )
    .join("");

  return `
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="mb-0 text-muted">Paiements enregistres: ${store.paiements.length}</p>
      <a href="#factures" class="btn btn-outline-primary">Voir les factures</a>
    </div>

    <div class="card mb-3">
      <div class="card-body">
        <h3 class="h6 mb-3">Saisir un paiement</h3>
        <form id="js-payment-form" class="row g-3" novalidate>
          <div class="col-md-4">
            <label class="form-label" for="payment-invoice">Facture *</label>
            <select id="payment-invoice" class="form-select" required>
              <option value="">Selectionner</option>
              ${invoiceOptions}
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label" for="payment-amount">Montant *</label>
            <input id="payment-amount" type="number" min="0.01" step="0.01" class="form-control" required />
          </div>
          <div class="col-md-3">
            <label class="form-label" for="payment-method">Mode *</label>
            <select id="payment-method" class="form-select" required>
              <option value="virement">virement</option>
              <option value="especes">especes</option>
              <option value="cheque">cheque</option>
            </select>
          </div>
          <div class="col-md-2">
            <label class="form-label" for="payment-date">Date *</label>
            <input id="payment-date" type="date" class="form-control" required />
          </div>
          <div class="col-12 d-flex gap-2">
            <button type="submit" class="btn btn-success">Enregistrer paiement</button>
          </div>
          <p class="text-danger mt-1 mb-0 small d-none" id="js-payment-form-error"></p>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr><th>ID</th><th>Facture</th><th>Montant</th><th>Mode</th><th>Date</th></tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="5" class="text-center text-muted py-4">Aucun paiement</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

export function renderCurrentRoute(store) {
  const route = getRouteFromHash();
  if (route === "users" && !isAdmin()) {
    window.location.hash = "#dashboard";
    return;
  }
  const config = views[route] || views.dashboard;

  const title = document.getElementById("view-title");
  const content = document.getElementById("view-content");
  title.textContent = config.title;
  content.innerHTML = config.render(store);
  if ((route in views ? route : "dashboard") === "prospects") {
    setupProspectsInteractions(store);
  }
  if ((route in views ? route : "dashboard") === "dashboard") {
    setupDashboardInteractions(store);
  }
  if ((route in views ? route : "dashboard") === "users") {
    setupUsersInteractions(store);
  }
  if ((route in views ? route : "dashboard") === "produits") {
    setupProductsInteractions(store);
  }
  if ((route in views ? route : "dashboard") === "opportunites") {
    setupOpportunitiesInteractions(store);
  }
  if ((route in views ? route : "dashboard") === "devis") {
    setupQuotesInteractions(store);
  }
  if ((route in views ? route : "dashboard") === "paiements") {
    setupPaymentsInteractions(store);
  }
  syncRoleNavigation();
  activateCurrentNav(route in views ? route : "dashboard");
}

export function initRouter(store) {
  window.addEventListener("hashchange", () => renderCurrentRoute(store));
  renderCurrentRoute(store);
}

function setupUsersInteractions(store) {
  if (!isAdmin()) {
    return;
  }

  const formWrapper = document.getElementById("js-user-form-wrapper");
  const form = document.getElementById("js-user-form");
  const formTitle = document.getElementById("js-user-form-title");
  const errorNode = document.getElementById("js-user-form-error");
  const hiddenId = document.getElementById("user-id");
  const usernameInput = document.getElementById("user-username");
  const fullNameInput = document.getElementById("user-fullname");
  const roleInput = document.getElementById("user-role");
  const activeInput = document.getElementById("user-active");
  const passwordInput = document.getElementById("user-password");
  const currentUser = getCurrentUser();

  function showForm(editing = false) {
    formTitle.textContent = editing ? "Modifier user" : "Nouveau user";
    errorNode.classList.add("d-none");
    formWrapper.classList.remove("d-none");
  }

  function hideForm() {
    form.reset();
    hiddenId.value = "";
    formWrapper.classList.add("d-none");
  }

  function persistAndRefresh() {
    saveCollection("users", store.users);
    renderCurrentRoute(store);
  }

  document.getElementById("js-new-user").addEventListener("click", () => {
    hideForm();
    showForm(false);
  });

  document.getElementById("js-cancel-user-form").addEventListener("click", () => hideForm());

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const username = usernameInput.value.trim();
    const fullName = fullNameInput.value.trim();
    const role = roleInput.value;
    const isActive = activeInput.value === "true";
    const password = passwordInput.value.trim();
    if (!username || !password) {
      errorNode.textContent = "Username et password sont obligatoires.";
      errorNode.classList.remove("d-none");
      return;
    }

    const duplicate = store.users.find((user) => user.username === username && user.id !== hiddenId.value.trim());
    if (duplicate) {
      errorNode.textContent = "Ce username existe deja.";
      errorNode.classList.remove("d-none");
      return;
    }

    const payload = { username, fullName, role, isActive, password };
    const editId = hiddenId.value.trim();
    if (editId) {
      store.users = store.users.map((item) => (item.id === editId ? { ...item, ...payload } : item));
    } else {
      const sequence = String(Date.now()).slice(-6);
      store.users.push({ id: `u-${sequence}`, ...payload });
    }
    persistAndRefresh();
  });

  document.querySelectorAll(".js-edit-user").forEach((button) => {
    button.addEventListener("click", () => {
      const row = store.users.find((item) => item.id === button.dataset.id);
      if (!row) return;
      hiddenId.value = row.id;
      usernameInput.value = row.username;
      fullNameInput.value = row.fullName || "";
      roleInput.value = row.role || "commercial";
      activeInput.value = String(row.isActive !== false);
      passwordInput.value = row.password || "";
      showForm(true);
    });
  });

  document.querySelectorAll(".js-delete-user").forEach((button) => {
    button.addEventListener("click", () => {
      const targetId = button.dataset.id;
      if (currentUser?.id === targetId) {
        window.alert("Vous ne pouvez pas supprimer l'utilisateur connecte.");
        return;
      }
      if (!window.confirm("Confirmer la suppression de ce user ?")) return;
      store.users = store.users.filter((item) => item.id !== targetId);
      persistAndRefresh();
    });
  });
}

function setupProductsInteractions(store) {
  if (!isAdmin()) {
    return;
  }

  const formWrapper = document.getElementById("js-product-form-wrapper");
  const form = document.getElementById("js-product-form");
  const formTitle = document.getElementById("js-product-form-title");
  const errorNode = document.getElementById("js-product-form-error");
  const hiddenId = document.getElementById("product-id");
  const nameInput = document.getElementById("product-name");
  const descriptionInput = document.getElementById("product-description");
  const priceInput = document.getElementById("product-price");

  function showForm(editing = false) {
    formTitle.textContent = editing ? "Modifier produit" : "Nouveau produit";
    errorNode.classList.add("d-none");
    formWrapper.classList.remove("d-none");
  }

  function hideForm() {
    form.reset();
    hiddenId.value = "";
    formWrapper.classList.add("d-none");
  }

  function persistAndRefresh() {
    saveCollection("produits", store.produits);
    renderCurrentRoute(store);
  }

  const newProductButton = document.getElementById("js-new-product");
  if (!newProductButton) return;

  newProductButton.addEventListener("click", () => {
    hideForm();
    showForm(false);
  });

  document.getElementById("js-cancel-product-form").addEventListener("click", () => hideForm());

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = nameInput.value.trim();
    const description = descriptionInput.value.trim();
    const unitPrice = Number(priceInput.value);
    if (!name || Number.isNaN(unitPrice) || unitPrice < 0) {
      errorNode.textContent = "Nom obligatoire et prix >= 0.";
      errorNode.classList.remove("d-none");
      return;
    }

    const payload = { name, description, unitPrice };
    const editId = hiddenId.value.trim();
    if (editId) {
      store.produits = store.produits.map((item) => (item.id === editId ? { ...item, ...payload } : item));
    } else {
      const sequence = String(Date.now()).slice(-6);
      store.produits.push({ id: `pr-${sequence}`, ...payload });
    }
    persistAndRefresh();
  });

  document.querySelectorAll(".js-edit-product").forEach((button) => {
    button.addEventListener("click", () => {
      const row = store.produits.find((item) => item.id === button.dataset.id);
      if (!row) return;
      hiddenId.value = row.id;
      nameInput.value = row.name;
      descriptionInput.value = row.description || "";
      priceInput.value = String(row.unitPrice || 0);
      showForm(true);
    });
  });

  document.querySelectorAll(".js-delete-product").forEach((button) => {
    button.addEventListener("click", () => {
      if (!window.confirm("Confirmer la suppression de ce produit ?")) return;
      store.produits = store.produits.filter((item) => item.id !== button.dataset.id);
      persistAndRefresh();
    });
  });
}

function setupProspectsInteractions(store) {
  const formWrapper = document.getElementById("js-prospect-form-wrapper");
  const form = document.getElementById("js-prospect-form");
  const formTitle = document.getElementById("js-form-title");
  const errorNode = document.getElementById("js-form-error");
  const searchInput = document.getElementById("js-search-prospect");
  const hiddenId = document.getElementById("prospect-id");
  const fullName = document.getElementById("fullName");
  const company = document.getElementById("company");
  const email = document.getElementById("email");
  const phone = document.getElementById("phone");
  const status = document.getElementById("status");

  function showForm(editing = false) {
    formTitle.textContent = editing ? "Modifier prospect/client" : "Nouveau prospect/client";
    errorNode.classList.add("d-none");
    formWrapper.classList.remove("d-none");
  }

  function hideForm() {
    form.reset();
    hiddenId.value = "";
    formWrapper.classList.add("d-none");
  }

  function validateForm() {
    if (!fullName.value.trim() || !email.value.trim() || !phone.value.trim() || !status.value.trim()) {
      return "Tous les champs obligatoires doivent etre remplis.";
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.value.trim())) {
      return "Le format de l'email est invalide.";
    }
    return "";
  }

  function persistAndRefresh() {
    saveCollection("prospects", store.prospects);
    renderCurrentRoute(store);
  }

  document.getElementById("js-new-prospect").addEventListener("click", () => {
    hideForm();
    showForm(false);
  });

  document.getElementById("js-cancel-form").addEventListener("click", () => hideForm());

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const validationMessage = validateForm();
    if (validationMessage) {
      errorNode.textContent = validationMessage;
      errorNode.classList.remove("d-none");
      return;
    }

    const payload = {
      fullName: fullName.value.trim(),
      company: company.value.trim(),
      email: email.value.trim(),
      phone: phone.value.trim(),
      status: status.value,
    };
    const editId = hiddenId.value.trim();

    if (editId) {
      store.prospects = store.prospects.map((item) => (item.id === editId ? { ...item, ...payload } : item));
    } else {
      const sequence = String(Date.now()).slice(-6);
      store.prospects.push({
        id: `p-${sequence}`,
        createdAt: new Date().toISOString().slice(0, 10),
        ...payload,
      });
    }

    persistAndRefresh();
  });

  document.querySelectorAll(".js-edit-prospect").forEach((button) => {
    button.addEventListener("click", () => {
      const row = store.prospects.find((item) => item.id === button.dataset.id);
      if (!row) {
        return;
      }
      hiddenId.value = row.id;
      fullName.value = row.fullName;
      company.value = row.company || "";
      email.value = row.email;
      phone.value = row.phone || "";
      status.value = row.status;
      showForm(true);
    });
  });

  document.querySelectorAll(".js-delete-prospect").forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.id;
      const confirmed = window.confirm("Confirmer la suppression de ce prospect/client ?");
      if (!confirmed) {
        return;
      }
      store.prospects = store.prospects.filter((item) => item.id !== id);
      persistAndRefresh();
    });
  });

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.trim().toLowerCase();
    const rows = Array.from(document.querySelectorAll("#js-prospect-table-body tr"));
    rows.forEach((row) => {
      const text = row.textContent.toLowerCase();
      row.classList.toggle("d-none", Boolean(query) && !text.includes(query));
    });
  });
}

function setupOpportunitiesInteractions(store) {
  const stagesOrder = ["nouveau", "en_cours", "negociation", "gagne", "perdu"];
  const formWrapper = document.getElementById("js-opportunity-form-wrapper");
  const form = document.getElementById("js-opportunity-form");
  const formTitle = document.getElementById("js-opportunity-form-title");
  const errorNode = document.getElementById("js-opportunity-form-error");
  const hiddenId = document.getElementById("opportunity-id");
  const titleInput = document.getElementById("opp-title");
  const prospectInput = document.getElementById("opp-prospect");
  const amountInput = document.getElementById("opp-amount");
  const probabilityInput = document.getElementById("opp-probability");
  const stageInput = document.getElementById("opp-stage");
  const closeDateInput = document.getElementById("opp-close-date");

  function showForm(editing = false) {
    formTitle.textContent = editing ? "Modifier opportunite" : "Nouvelle opportunite";
    errorNode.classList.add("d-none");
    formWrapper.classList.remove("d-none");
  }

  function hideForm() {
    form.reset();
    hiddenId.value = "";
    formWrapper.classList.add("d-none");
  }

  function persistAndRefresh() {
    saveCollection("opportunites", store.opportunites);
    renderCurrentRoute(store);
  }

  function validateOpportunityForm() {
    if (
      !titleInput.value.trim() ||
      !prospectInput.value.trim() ||
      !amountInput.value.trim() ||
      !probabilityInput.value.trim() ||
      !stageInput.value.trim() ||
      !closeDateInput.value.trim()
    ) {
      return "Tous les champs obligatoires doivent etre remplis.";
    }

    const amount = Number(amountInput.value);
    const probability = Number(probabilityInput.value);
    if (Number.isNaN(amount) || amount < 0) {
      return "Le montant estime doit etre un nombre positif.";
    }
    if (Number.isNaN(probability) || probability < 0 || probability > 100) {
      return "La probabilite doit etre entre 0 et 100.";
    }

    return "";
  }

  document.getElementById("js-new-opportunity").addEventListener("click", () => {
    hideForm();
    showForm(false);
  });

  document.getElementById("js-cancel-opportunity-form").addEventListener("click", () => hideForm());

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const validationMessage = validateOpportunityForm();
    if (validationMessage) {
      errorNode.textContent = validationMessage;
      errorNode.classList.remove("d-none");
      return;
    }

    const payload = {
      title: titleInput.value.trim(),
      prospectId: prospectInput.value,
      amount: Number(amountInput.value),
      probability: Number(probabilityInput.value),
      stage: stageInput.value,
      expectedCloseDate: closeDateInput.value,
    };

    const editId = hiddenId.value.trim();
    if (editId) {
      store.opportunites = store.opportunites.map((item) => (item.id === editId ? { ...item, ...payload } : item));
    } else {
      const sequence = String(Date.now()).slice(-6);
      store.opportunites.push({
        id: `o-${sequence}`,
        ...payload,
      });
    }

    persistAndRefresh();
  });

  document.querySelectorAll(".js-edit-opportunity").forEach((button) => {
    button.addEventListener("click", () => {
      const row = store.opportunites.find((item) => item.id === button.dataset.id);
      if (!row) {
        return;
      }

      hiddenId.value = row.id;
      titleInput.value = row.title;
      prospectInput.value = row.prospectId;
      amountInput.value = String(row.amount);
      probabilityInput.value = String(row.probability);
      stageInput.value = row.stage;
      closeDateInput.value = row.expectedCloseDate;
      showForm(true);
    });
  });

  document.querySelectorAll(".js-move-opportunity").forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.id;
      const direction = button.dataset.direction;
      const target = store.opportunites.find((item) => item.id === id);
      if (!target) {
        return;
      }

      const currentIndex = stagesOrder.indexOf(target.stage);
      const nextIndex = direction === "next" ? currentIndex + 1 : currentIndex - 1;
      if (nextIndex < 0 || nextIndex >= stagesOrder.length) {
        return;
      }

      target.stage = stagesOrder[nextIndex];
      persistAndRefresh();
    });
  });
}

function setupQuotesInteractions(store) {
  const formWrapper = document.getElementById("js-quote-form-wrapper");
  const form = document.getElementById("js-quote-form");
  const formTitle = document.getElementById("js-quote-form-title");
  const errorNode = document.getElementById("js-quote-form-error");
  const hiddenId = document.getElementById("quote-id");
  const prospectInput = document.getElementById("quote-prospect");
  const statusInput = document.getElementById("quote-status");
  const linesContainer = document.getElementById("js-quote-lines");
  const subtotalNode = document.getElementById("js-quote-subtotal");
  const totalNode = document.getElementById("js-quote-total");
  const searchInput = document.getElementById("js-search-quote");
  const statusFilter = document.getElementById("js-filter-quote-status");

  function lineTemplate(line = { productId: "", description: "", quantity: 1, unitPrice: 0 }) {
    const productOptions = store.produits
      .map(
        (product) =>
          `<option value="${product.id}" ${line.productId === product.id ? "selected" : ""}>${product.name} (${formatAmount(product.unitPrice)} MAD)</option>`
      )
      .join("");
    return `
      <div class="row g-2 mb-2 js-quote-line">
        <div class="col-md-4">
          <select class="form-select js-line-product">
            <option value="">Produit libre</option>
            ${productOptions}
          </select>
        </div>
        <div class="col-md-4">
          <input type="text" class="form-control js-line-description" placeholder="Description" value="${line.description || ""}" />
        </div>
        <div class="col-md-2">
          <input type="number" class="form-control js-line-quantity" min="1" value="${line.quantity || 1}" />
        </div>
        <div class="col-md-1">
          <input type="number" class="form-control js-line-unit-price" min="0" value="${line.unitPrice || 0}" />
        </div>
        <div class="col-md-1 d-grid">
          <button type="button" class="btn btn-outline-danger js-remove-line">x</button>
        </div>
      </div>
    `;
  }

  function resetLines(lines = [{ description: "", quantity: 1, unitPrice: 0 }]) {
    linesContainer.innerHTML = lines.map((line) => lineTemplate(line)).join("");
    bindLineEvents();
    recalculateTotal();
  }

  function bindLineEvents() {
    linesContainer.querySelectorAll(".js-remove-line").forEach((button) => {
      button.addEventListener("click", () => {
        const totalLines = linesContainer.querySelectorAll(".js-quote-line").length;
        if (totalLines <= 1) return;
        button.closest(".js-quote-line").remove();
        recalculateTotal();
      });
    });
    linesContainer.querySelectorAll(".js-line-product").forEach((select) => {
      select.addEventListener("change", () => {
        const row = select.closest(".js-quote-line");
        const selected = store.produits.find((product) => product.id === select.value);
        if (!row) return;
        const descriptionInput = row.querySelector(".js-line-description");
        const priceInput = row.querySelector(".js-line-unit-price");
        if (selected) {
          descriptionInput.value = selected.name;
          priceInput.value = String(selected.unitPrice);
        }
        recalculateTotal();
      });
    });
    linesContainer.querySelectorAll("input").forEach((input) => {
      input.addEventListener("input", () => recalculateTotal());
    });
  }

  function getLines() {
    return Array.from(linesContainer.querySelectorAll(".js-quote-line")).map((lineNode) => ({
      productId: lineNode.querySelector(".js-line-product").value || "",
      description: lineNode.querySelector(".js-line-description").value.trim(),
      quantity: Number(lineNode.querySelector(".js-line-quantity").value),
      unitPrice: Number(lineNode.querySelector(".js-line-unit-price").value),
    }));
  }

  function recalculateTotal() {
    const lines = getLines();
    const subtotal = lines.reduce((sum, line) => sum + Number(line.quantity || 0) * Number(line.unitPrice || 0), 0);
    subtotalNode.textContent = formatAmount(subtotal);
    totalNode.textContent = formatAmount(subtotal);
    return subtotal;
  }

  function showForm(editing = false) {
    formTitle.textContent = editing ? "Modifier devis" : "Nouveau devis";
    errorNode.classList.add("d-none");
    formWrapper.classList.remove("d-none");
  }

  function hideForm() {
    form.reset();
    hiddenId.value = "";
    formWrapper.classList.add("d-none");
    resetLines();
  }

  function validateQuoteForm(lines) {
    if (!prospectInput.value.trim() || !statusInput.value.trim()) {
      return "Tous les champs obligatoires doivent etre remplis.";
    }
    if (lines.length === 0) {
      return "Ajoutez au moins une ligne.";
    }
    const hasInvalidLine = lines.some(
      (line) => !line.description || Number.isNaN(line.quantity) || line.quantity <= 0 || Number.isNaN(line.unitPrice) || line.unitPrice < 0
    );
    if (hasInvalidLine) {
      return "Chaque ligne doit avoir une description, une quantite > 0 et un prix >= 0.";
    }
    return "";
  }

  function persistAndRefresh() {
    saveCollection("devis", store.devis);
    renderCurrentRoute(store);
  }

  function applyTableFilters() {
    const query = searchInput.value.trim().toLowerCase();
    const statusValue = statusFilter.value.trim().toLowerCase();
    const rows = Array.from(document.querySelectorAll("#js-quote-table-body tr"));
    rows.forEach((row) => {
      const text = row.textContent.toLowerCase();
      const matchesQuery = !query || text.includes(query);
      const matchesStatus = !statusValue || text.includes(statusValue);
      row.classList.toggle("d-none", !(matchesQuery && matchesStatus));
    });
  }

  document.getElementById("js-new-quote").addEventListener("click", () => {
    hideForm();
    showForm(false);
  });

  document.getElementById("js-cancel-quote-form").addEventListener("click", () => hideForm());

  document.getElementById("js-add-quote-line").addEventListener("click", () => {
    linesContainer.insertAdjacentHTML("beforeend", lineTemplate());
    bindLineEvents();
    recalculateTotal();
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const lines = getLines();
    const validationMessage = validateQuoteForm(lines);
    if (validationMessage) {
      errorNode.textContent = validationMessage;
      errorNode.classList.remove("d-none");
      return;
    }

    const total = recalculateTotal();
    const payload = {
      prospectId: prospectInput.value,
      status: statusInput.value,
      lines,
      total,
    };

    const editId = hiddenId.value.trim();
    if (editId) {
      store.devis = store.devis.map((item) => (item.id === editId ? { ...item, ...payload } : item));
    } else {
      const sequence = String(Date.now()).slice(-6);
      store.devis.push({
        id: `d-${sequence}`,
        createdAt: new Date().toISOString().slice(0, 10),
        ...payload,
      });
    }

    persistAndRefresh();
  });

  document.querySelectorAll(".js-edit-quote").forEach((button) => {
    button.addEventListener("click", () => {
      const row = store.devis.find((item) => item.id === button.dataset.id);
      if (!row) return;

      hiddenId.value = row.id;
      prospectInput.value = row.prospectId;
      statusInput.value = row.status;
      resetLines(row.lines?.length ? row.lines : undefined);
      showForm(true);
    });
  });

  document.querySelectorAll(".js-delete-quote").forEach((button) => {
    button.addEventListener("click", () => {
      if (!window.confirm("Confirmer la suppression de ce devis ?")) return;
      store.devis = store.devis.filter((item) => item.id !== button.dataset.id);
      persistAndRefresh();
    });
  });

  document.querySelectorAll(".js-convert-quote").forEach((button) => {
    button.addEventListener("click", () => {
      const quote = store.devis.find((item) => item.id === button.dataset.id);
      if (!quote || quote.status !== "accepte") return;
      const alreadyExists = store.factures.some((invoice) => invoice.devisId === quote.id);
      if (alreadyExists) {
        window.alert("Une facture existe deja pour ce devis.");
        return;
      }

      const sequence = String(Date.now()).slice(-6);
      const invoice = {
        id: `f-${sequence}`,
        devisId: quote.id,
        status: "emise",
        total: Number(quote.total || 0),
        paidAmount: 0,
        remainingAmount: Number(quote.total || 0),
        lines: (quote.lines || []).map((line) => ({
          ...line,
          productName: resolveProductName(store, line.productId) || line.description,
        })),
        createdAt: new Date().toISOString().slice(0, 10),
      };
      store.factures.push(invoice);
      saveCollection("factures", store.factures);
      renderCurrentRoute(store);
    });
  });

  searchInput.addEventListener("input", applyTableFilters);
  statusFilter.addEventListener("change", applyTableFilters);
  resetLines();
}

function resolveProspectName(store, prospectId) {
  const prospect = store.prospects.find((item) => item.id === prospectId);
  return prospect ? prospect.fullName : "Prospect inconnu";
}

function resolveProductName(store, productId) {
  if (!productId) return "";
  const product = store.produits.find((item) => item.id === productId);
  return product ? product.name : "";
}

function formatAmount(value) {
  return new Intl.NumberFormat("fr-FR").format(Number(value || 0));
}

function quoteStatusColor(status) {
  if (status === "accepte") return "success";
  if (status === "refuse") return "danger";
  if (status === "envoye") return "primary";
  return "secondary";
}

function invoiceStatusColor(status) {
  if (status === "payee") return "success";
  if (status === "partiellement_payee") return "warning";
  return "primary";
}

function recomputeInvoice(invoice) {
  const total = Number(invoice.total || 0);
  const paid = Number(invoice.paidAmount || 0);
  const remaining = Math.max(0, total - paid);
  let status = "emise";
  if (remaining === 0) {
    status = "payee";
  } else if (paid > 0) {
    status = "partiellement_payee";
  }
  return { ...invoice, remainingAmount: remaining, status };
}

function setupPaymentsInteractions(store) {
  const form = document.getElementById("js-payment-form");
  if (!form) return;

  const invoiceInput = document.getElementById("payment-invoice");
  const amountInput = document.getElementById("payment-amount");
  const methodInput = document.getElementById("payment-method");
  const dateInput = document.getElementById("payment-date");
  const errorNode = document.getElementById("js-payment-form-error");

  if (!dateInput.value) {
    dateInput.value = new Date().toISOString().slice(0, 10);
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    errorNode.classList.add("d-none");

    const invoiceId = invoiceInput.value.trim();
    const amount = Number(amountInput.value);
    const method = methodInput.value.trim();
    const paidAt = dateInput.value;

    if (!invoiceId || Number.isNaN(amount) || amount <= 0 || !method || !paidAt) {
      errorNode.textContent = "Tous les champs sont obligatoires et le montant doit etre > 0.";
      errorNode.classList.remove("d-none");
      return;
    }

    const invoiceIndex = store.factures.findIndex((item) => item.id === invoiceId);
    if (invoiceIndex < 0) {
      errorNode.textContent = "Facture introuvable.";
      errorNode.classList.remove("d-none");
      return;
    }

    const invoice = store.factures[invoiceIndex];
    if (amount > Number(invoice.remainingAmount || 0)) {
      errorNode.textContent = "Le montant depasse le reste a payer de la facture.";
      errorNode.classList.remove("d-none");
      return;
    }

    const sequence = String(Date.now()).slice(-6);
    store.paiements.push({
      id: `pay-${sequence}`,
      invoiceId,
      amount,
      method,
      paidAt,
    });

    const updatedInvoice = recomputeInvoice({
      ...invoice,
      paidAmount: Number(invoice.paidAmount || 0) + amount,
    });
    store.factures[invoiceIndex] = updatedInvoice;

    saveCollection("paiements", store.paiements);
    saveCollection("factures", store.factures);
    renderCurrentRoute(store);
  });
}

function setupDashboardInteractions(store) {
  const searchInput = document.getElementById("js-global-search");
  const filterInput = document.getElementById("js-global-filter");
  const resultsNode = document.getElementById("js-global-results");

  if (!searchInput || !filterInput || !resultsNode) {
    return;
  }

  function searchEntries(query, filter) {
    const groups = [
      {
        type: "prospects",
        route: "#prospects",
        items: store.prospects.map((item) => ({ id: item.id, text: `${item.fullName} ${item.company || ""} ${item.email || ""}` })),
      },
      {
        type: "opportunites",
        route: "#opportunites",
        items: store.opportunites.map((item) => ({ id: item.id, text: `${item.title} ${item.stage} ${item.amount}` })),
      },
      {
        type: "devis",
        route: "#devis",
        items: store.devis.map((item) => ({ id: item.id, text: `${item.id} ${item.status} ${item.total}` })),
      },
      {
        type: "factures",
        route: "#factures",
        items: store.factures.map((item) => ({ id: item.id, text: `${item.id} ${item.status} ${item.total}` })),
      },
    ];

    const normalized = query.trim().toLowerCase();
    if (!normalized) return [];

    return groups
      .filter((group) => filter === "all" || group.type === filter)
      .flatMap((group) =>
        group.items
          .filter((item) => item.text.toLowerCase().includes(normalized))
          .map((item) => ({ ...item, type: group.type, route: group.route }))
      )
      .slice(0, 20);
  }

  function renderSearchResults() {
    const results = searchEntries(searchInput.value, filterInput.value);
    if (!searchInput.value.trim()) {
      resultsNode.innerHTML = "Tapez un mot-cle pour afficher les resultats.";
      return;
    }
    if (!results.length) {
      resultsNode.innerHTML = "Aucun resultat.";
      return;
    }

    resultsNode.innerHTML = results
      .map(
        (result) =>
          `<div class="small mb-1"><span class="badge text-bg-light me-1">${result.type}</span><a href="${result.route}">${result.id}</a></div>`
      )
      .join("");
  }

  searchInput.addEventListener("input", renderSearchResults);
  filterInput.addEventListener("change", renderSearchResults);

  document.querySelectorAll(".js-export-csv").forEach((button) => {
    button.addEventListener("click", () => {
      const entity = button.dataset.entity;
      const rows = store[entity] || [];
      downloadCsv(`${entity}.csv`, rows);
    });
  });
}

function downloadCsv(fileName, rows) {
  const csv = rowsToCsv(rows);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function rowsToCsv(rows) {
  if (!rows.length) return "";
  const headers = Array.from(new Set(rows.flatMap((row) => Object.keys(row))));
  const escapeCsv = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const lines = [
    headers.join(","),
    ...rows.map((row) =>
      headers
        .map((header) => escapeCsv(typeof row[header] === "object" ? JSON.stringify(row[header]) : row[header]))
        .join(",")
    ),
  ];
  return lines.join("\n");
}

function isAdmin() {
  const user = getCurrentUser();
  return user?.role === "admin";
}

function syncRoleNavigation() {
  const usersLink = document.querySelector('a.route-link[href="#users"]');
  if (!usersLink) return;
  usersLink.parentElement?.classList.toggle("d-none", !isAdmin());
}
