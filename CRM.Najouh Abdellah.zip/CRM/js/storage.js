const DATA_KEYS = ["users", "prospects", "produits", "opportunites", "devis", "factures", "paiements"];
const STORAGE_PREFIX = "mini-crm";

async function fetchJson(fileName) {
  const response = await fetch(`data/${fileName}.json`);
  if (!response.ok) {
    throw new Error(`Impossible de charger data/${fileName}.json`);
  }
  return response.json();
}

export async function loadDataStore() {
  const entries = await Promise.all(
    DATA_KEYS.map(async (key) => {
      const cached = localStorage.getItem(`${STORAGE_PREFIX}:${key}`);
      if (cached) {
        return [key, JSON.parse(cached)];
      }
      const value = await fetchJson(key);
      return [key, value];
    })
  );

  return Object.fromEntries(entries);
}

export function saveCollection(key, rows) {
  localStorage.setItem(`${STORAGE_PREFIX}:${key}`, JSON.stringify(rows));
}
